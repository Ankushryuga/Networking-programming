#include "../Header/udpServer.h"

int main(){

    udpSample();
    return 0;
}