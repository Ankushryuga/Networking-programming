#include "../Header/udpServer.h"

static void udpserver::udpSample(){
    struct sockaddr_in sv_addr, cl_addr;
    struct stat st;
    struct frame_t frame;
    struct timeval t_out={0,0};

    char msg_recv[BUF_SIZE];
    char flname_recv[20];
    char cmd_recv[10];

    ssize_t numRead;
    ssize_t length;
    off_t f_size;
    long int ack_num=0;
    int ack_send=0;
    int sfd;

    //file 
    FILE *fptr; 
    memset(&sv_addr,0,sizeof(sv_addr));
    sv_addr.sin_family=AF_INET;
    sv_addr.sin_port=htons(atoi[argv[1]]);
    sv_addr.sin_addr.s_addr=INADDR_ANY;

    if((sfd=socket(AF_INET, SOCK_DGRAM, 0))=-1)
            cerr<<"server:socket failed: "<<endl;
    
    if(bind(sfd, (struct sockaddr *)&sv_addr, sizeof(sv_addr))=-1)
            cerr<<"server: bind failed: "<<endl;



    for(;;){
        cout<<"Server: waiting for client to connect: "<<end;
        memset(msg_recv,0,sizeof(msg_recv));
        memset(cmd_recv,0,sizeof(cmd_recv));
        memset(flname_recv,0,sizeof(flname_recv));

        length=sizeof(cl_addr);

        if((numRead=recvfrom(sfd, msg_recv, BUF_SIZE, 0, (struct sockaddr *)&cl_addr, (socklen_t *)&length))=-1)
                cerr<<"server:reveive =error"<<endl;

        cout<<"server: recived message: "<<msg_recv;
        sscan(msg_recv,"%s %s", cmd_recv, flname_recv);

        ////////// get file ////////
     
		if ((strcmp(cmd_recv, "get") == 0) && (flname_recv[0] != '\0')) {

			//printf("Server: Get called with file name --> %s\n", flname_recv);
            cout<<"Server: Get called with file name- ---->"<<flname_recv;

			if (access(flname_recv, F_OK) == 0) {			//Check if file exist
				
				int total_frame = 0, resend_frame = 0, drop_frame = 0, t_out_flag = 0;
				long int i = 0;
					
				stat(flname_recv, &st);
				f_size = st.st_size;			//Size of the file

				t_out.tv_sec = 2;			
				t_out.tv_usec = 0;
				setsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval));   //Set timeout option for recvfrom

				fptr = fopen(flname_recv, "rb");        //open the file to be sent
					
				if ((f_size % BUF_SIZE) != 0)
					total_frame = (f_size / BUF_SIZE) + 1;				//Total number of frames to be sent
				else
					total_frame = (f_size / BUF_SIZE);

				//printf("Total number of packets ---> %d\n", total_frame);
                cout<<"total number of packets--->"<<total_frame;
					
				length = sizeof(cl_addr);

				sendto(sfd, &(total_frame), sizeof(total_frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr));	//Send number of packets (to be transmitted) to reciever
				recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);

				while (ack_num != total_frame)		//Check for the acknowledgement
				{
					/*keep Retrying until the ack matches*/
					sendto(sfd, &(total_frame), sizeof(total_frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr)); 
					recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);

					resend_frame++;

					/*Enable timeout flag even if it fails after 20 tries*/
					if (resend_frame == 20) {
						t_out_flag = 1;
						break;
					}
				}

				/*transmit data frames sequentially followed by an acknowledgement matching*/
				for (i = 1; i <= total_frame; i++)
				{
					memset(&frame, 0, sizeof(frame));
					ack_num = 0;
					frame.ID = i;
					frame.length = fread(frame.data, 1, BUF_SIZE, fptr);

					sendto(sfd, &(frame), sizeof(frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr));		//send the frame
					recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);	//Recieve the acknowledgement

					while (ack_num != frame.ID)  //Check for ack
					{
						/*keep retrying until the ack matches*/
						sendto(sfd, &(frame), sizeof(frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr));
						recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);
					//	printf("frame ---> %ld	dropped, %d times\n", frame.ID, ++drop_frame);
                        cout<<"frame--->"<<frame.ID<<" Dropped "<<++drop_frame<<"time"<<endl;
						
						resend_frame++;

						//printf("frame ---> %ld	dropped, %d times\n", frame.ID, drop_frame);
                        cout<<"frame--->"<<frame.ID<<" Dropped "<<++drop_frame<<"time"<<endl;
						/*Enable the timeout flag even if it fails after 200 tries*/
						if (resend_frame == 200) {
							t_out_flag = 1;
							break;
						}
					}

					resend_frame = 0;
					drop_frame = 0;

					/*File transfer fails if timeout occurs*/
					if (t_out_flag == 1) {
						//printf("File not sent\n");
                        cout<<"File not sent"<<endl;
						break;
					}

				//	printf("frame ----> %ld	Ack ----> %ld \n", i, ack_num);
                    cout<<"fram----->"<<i<<" ACK------>"<<ack_num<<endl;

					if (total_frame == ack_num)
					//	printf("File sent\n");
                        cout<<"File sent"<<endl;
				}
				fclose(fptr);

				t_out.tv_sec = 0;
				t_out.tv_usec = 0;
				setsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); //Disable the timeout option
			}
			else {	
				//printf("Invalid Filename\n");
                cout<<"Invalid filename: "<<endl;
			}
		}




}}