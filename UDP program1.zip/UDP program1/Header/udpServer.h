#ifndef _UDPSERVER_H_
#define _UDPSERVER_H_

#include<bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <dirent.h>
#include<fstream>

#define BUF_SIZE (2048)		//Max buffer size of the data in a frame

/*A frame packet with unique id, length and data*/
struct frame_t {
	long int ID;
	long int length;
	char data[BUF_SIZE];
};


using namespace std;

class udpserver{
        private:
        public:
        static void print_error(const char *msg, ...);
        void udpSample();
};

