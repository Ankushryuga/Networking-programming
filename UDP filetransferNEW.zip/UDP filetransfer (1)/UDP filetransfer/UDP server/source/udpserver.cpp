#include "../header/udpserver.h"

udpServer::udpServer(){
    FILE *fptr;     //file pointer;
int broadcast =1;
    memset(&sv_addr,0, sizeof(sv_addr));
    sv_addr.sin_family=AF_INET;
    sv_addr.sin_port = htons(port);
	sv_addr.sin_addr.s_addr = INADDR_ANY;

    if((sfd=socket(AF_INET, SOCK_DGRAM, 0))==-1){
        cout<<"Server socket error: "<<endl;
    }

	 if(setsockopt(sfd, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) <0)
   {
   
    perror("socket set error...\n");
    exit(-1);
   }
 
    if(bind(sfd, (struct sockaddr *) &sv_addr, sizeof(sv_addr))==-1){
        cout<<"Server: Bind"<<endl;   
    }
    for(;;){
        cout<<"Server:waiting for client to connect: "<<endl;
        memset(msg_recv, 0, sizeof(msg_recv));
        memset(cmd_recv, 0, sizeof(cmd_recv));
        memset(flname_recv, 0, sizeof(flname_recv));

        length=sizeof(cl_addr);
        if((numRead=recvfrom(sfd, msg_recv, BUF_SIZE, 0, (struct sockaddr *)&cl_addr, (socklen_t*)&length))==-1)
            cerr<<"server:receive= ";
        cerr<<"server: the received message:====> "<<msg_recv<<endl;
        
        sscanf(msg_recv, "%s %s", cmd_recv, flname_recv);

        if((strcmp(cmd_recv,"FIND")==0) && (flname_recv[0]!='\0')){
            cout<<"Server: Get called with file name --> "<<flname_recv<<endl;

			if (access(flname_recv, F_OK) == 0) {			//Check if file exist
				
				int total_frame = 0, resend_frame = 0, drop_frame = 0, t_out_flag = 0;
				long int i = 0;
					
				stat(flname_recv, &st);
				f_size = st.st_size;			//Size of the file

				t_out.tv_sec = 2;			
				t_out.tv_usec = 0;
				setsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval));   //Set timeout option for recvfrom

				fptr = fopen(flname_recv, "rb");        //open the file to be sent
					
				if ((f_size % BUF_SIZE) != 0)
					total_frame = (f_size / BUF_SIZE) + 1;				//Total number of frames to be sent
				else
					total_frame = (f_size / BUF_SIZE);

				cerr<<"Total number of packets --->"<< total_frame<<endl;
					
				length = sizeof(cl_addr);

				sendto(sfd, &(total_frame), sizeof(total_frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr));	//Send number of packets (to be transmitted) to reciever
				recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);

				while (ack_num != total_frame)		//Check for the acknowledgement
				{
					/*keep Retrying until the ack matches*/
					sendto(sfd, &(total_frame), sizeof(total_frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr)); 
					recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);

					resend_frame++;

					/*Enable timeout flag even if it fails after 20 tries*/
					if (resend_frame == 20) {
						t_out_flag = 1;
						break;
					}
				}

				/*transmit data frames sequentially followed by an acknowledgement matching*/
				for (i = 1; i <= total_frame; i++)
				{
					memset(&frame, 0, sizeof(frame));
					ack_num = 0;
					frame.ID = i;
					frame.length = fread(frame.data, 1, BUF_SIZE, fptr);

					sendto(sfd, &(frame), sizeof(frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr));		//send the frame
					recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);	//Recieve the acknowledgement

					while (ack_num != frame.ID)  //Check for ack
					{
						/*keep retrying until the ack matches*/
						sendto(sfd, &(frame), sizeof(frame), 0, (struct sockaddr *) &cl_addr, sizeof(cl_addr));
						recvfrom(sfd, &(ack_num), sizeof(ack_num), 0, (struct sockaddr *) &cl_addr, (socklen_t *) &length);
						cout<<"frame ---> %ld	dropped, %d times\n", frame.ID, ++drop_frame;
                        cout<<"frame ---> "<<frame.ID<<"  Dropped "<<++drop_frame <<"times"<<endl;
						
						resend_frame++;

						//cout<<"frame ---> %ld	dropped, %d times\n", frame.ID, drop_frame;
                        cout<<"frame ---> "<<frame.ID<<"  Dropped "<<++drop_frame <<"times"<<endl;

						/*Enable the timeout flag even if it fails after 200 tries*/
						if (resend_frame == 200) {
							t_out_flag = 1;
							break;
						}
					}

					resend_frame = 0;
					drop_frame = 0;

					/*File transfer fails if timeout occurs*/
					if (t_out_flag == 1) {
						//printf("File not sent\n");
                        cout<<"FIle not found: "<<endl;
						break;
					}

					//cout<<"frame ----> %ld	Ack ----> %ld \n", i, ack_num;
                    cout<<"frame----> "<<i<<"  Ack ----->"<<ack_num<<endl;

					if (total_frame == ack_num)
						//printf("File sent\n");
                        cout<<"File sent"<<endl;
				}
				fclose(fptr);

				t_out.tv_sec = 0;
				t_out.tv_usec = 0;
				setsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); //Disable the timeout option
			}
			else {	
				//printf("Invalid Filename\n");
                cout<<"Invalid filename:" <<endl;
			}
        }

    }
}
udpServer::~udpServer(){
    cout<<"objects destroyed:  "<<endl;
}