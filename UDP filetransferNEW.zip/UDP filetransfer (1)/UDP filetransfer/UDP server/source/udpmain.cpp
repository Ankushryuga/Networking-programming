#include "../header/udpserver.h"

int main(){
    udpServer server;
    server.~udpServer();


    return 0;
}