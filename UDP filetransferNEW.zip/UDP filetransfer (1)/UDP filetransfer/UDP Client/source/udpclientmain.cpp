#include"../header/udpclient.h"

int main(){
    udpclient client;
    client.~udpclient();
    return 0;
}